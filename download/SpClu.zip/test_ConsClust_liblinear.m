function  test_ConsClust_liblinear()

addpath(genpath('helpers'));
addpath(genpath('lobpcg'));
addpath(genpath('CMG_101014'));

close all; 

train_ratio = 10;

% nrVertexConstrains = the  number of nodes involved in the ML/CL constraints
%  nrVertexConstrains = 50
nrVertexConstrains = 100;

FileName = [ 'Test_FourMoons_C' int2str(nrVertexConstrains) '.mat' ];
load(FileName,'G','Q','nrClust','alpha','Coord', 'GroundTruth');


%% Run constrained clustering
% [ ~, EIGVECTS, ~ ] = run_ConsClust(G, Q, nrClust, alpha);
[ EIGVECTS, EIGVECTS_raw, lambda, failureFlag ] = baseline_SpectralEmbedding( G, nrClust);




[n,~] = size(G);
%% Run liblinear

% See more: https://github.com/cjlin1/liblinear
% Use a smaller stopping tolerance 0.0001 than the default 0.1 for more accurate solutions.
trainid = randsample([1:n],floor(train_ratio/100*n));
temp = zeros(1,n);
temp(trainid) = 1;
testid = find(temp~=1);
model = train(GroundTruth(trainid), sparse(EIGVECTS(trainid,:)), '-s 0 -q  -e 0.00001 -nr_class'+ nrClust, 'row'); 

[clus_vec, accuracy, ~] = predict(GroundTruth(testid), sparse(EIGVECTS(testid,:)), model, '-b 0','row');
sprintf('accuracy (for classification): %12.2f\nmean squared error: %12.2f\n',...
    accuracy(1),accuracy(2)) 

%% Visualize the result and compute errors:
ColorSet = myvarycolor(round(nrClust));   % set(gca,'ColorOrder',ColorSet);
hold all;
Coord_test = Coord(testid,:);
for i=1:nrClust
    labHere = find(clus_vec ==i);
%     labHere = find(IDX_kmeans==i);
    plot(Coord_test(labHere,1),  Coord_test(labHere,2), '.','MarkerSize',10, ...
        'Color', ColorSet(i,:));
end
axis tight;

% Compute the Rand Index
% [AR_kmeans,RI_kmeans] = valid_RandIndex( GroundTruth  ,IDX_kmeans) ; %    ,RI,MI,HI

[AR_kmeans,RI_kmeans] = valid_RandIndex( GroundTruth(testid),clus_vec);
title([ '# constraints = '  int2str(nrVertexConstrains) ...
    '; AR=' num2str(myround(AR_kmeans,2))  ...
    '; RI=' num2str(myround(RI_kmeans,2)) ], 'FontSize',22);

end

