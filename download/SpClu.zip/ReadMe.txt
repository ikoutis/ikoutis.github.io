
Implements the constrained clustering algorithm in 

M. Cucuringu, I. Koutis, S. Chawla, G. Miller, and R. Peng 
"Simple and Scalable Constrained Clustering: A Generalized Spectral Method"
to appear in AISTATS 2016, (arXiv:1504.00653)



test_ConsClust: contains two examples

run_ConsClust: the main function for running constrained clustering


