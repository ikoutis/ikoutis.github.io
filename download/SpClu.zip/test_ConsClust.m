function  test_ConsClust()

addpath(genpath('helpers'));
addpath(genpath('lobpcg'));
addpath(genpath('CMG_101014'));

close all; 

% nrVertexConstrains = the  number of nodes involved in the ML/CL constraints
%  nrVertexConstrains = 50
nrVertexConstrains = 100;

FileName = [ 'Test_FourMoons_C' int2str(nrVertexConstrains) '.mat' ];
load(FileName,'G','Q','nrClust','alpha','Coord', 'GroundTruth');


%% Run constrained clustering
% [ IDX_kmeans, EIGVECTS, ~ ] = run_ConsClust(G, Q, nrClust, alpha);
tic;[EIGVECTS, erb, ~, failureFlag] = baseline_SpectralEmbedding(G, nrClust); toc;

IDX_kmeans = kmeans_pp(EIGVECTS , nrClust);

%% Visualize the result and compute errors:
ColorSet = myvarycolor(round(nrClust));   % set(gca,'ColorOrder',ColorSet);
hold all;
for i=1:nrClust
    labHere = find(IDX_kmeans==i);
    plot(Coord(labHere,1),  Coord(labHere,2), '.','MarkerSize',10, ...
        'Color', ColorSet(i,:));
end
axis tight;

% Compute the Rand Index
[AR_kmeans,RI_kmeans] = valid_RandIndex( GroundTruth  ,IDX_kmeans) ; %    ,RI,MI,HI

title([ '# constraints = '  int2str(nrVertexConstrains) ...
    '; AR=' num2str(myround(AR_kmeans,2))  ...
    '; RI=' num2str(myround(RI_kmeans,2)) ], 'FontSize',22);

end

