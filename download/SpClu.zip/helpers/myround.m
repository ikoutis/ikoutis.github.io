function x = myround(x,k);    x = round(x* 10^k)/(10^k);    end
