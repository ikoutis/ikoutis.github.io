function [ EIGVECTS, EIGVECTS_raw ] = run_ConsEmbedding( G, Q, nrClust,alpha)

%% Requires the solver from    http://www.cs.cmu.edu/~jkoutis/cmg.html
%  Download it and follow the instructions in the ReadtMe.txt file
%  (to install it, run the command:     MakeCMG.m   )

%% Input:
% G = the given (undirected,possibly weighted) graph 
% Q = the constraint matrix         %  (ML = -1).  (CL = +1);
    % Q_{ij} = 0 if no constraints
    % Q_{ij} = -1 if same clusters
    % Q_{ij} = 1 if opposite clusters
% nrClust = number of clusters;
% alpha = alpha parameter (see paper, page 3, column 1);


%% Output: 
% IDX_kmeans    = cluster ID for each node based on k-means clustering 
% EIGVECTS      = GE embedding after the projection
% EIGVECTS_raw  = GE embedding before the projection

% Note that the the cmg solver may fail if the matrices are too dense.



%% Build the two graph Laplacians
G = sparse(G);
Q = sparse(Q);
n = length(G);
degsG = full(sum(G))';  % column vector

% Q:  is such that (ML = -1)  and  (CL = +1)
% figure(2);  colormap('hot');  imagesc(Q);  colorbar;set(gca,'FontSize',18);  input('W');

QGplus = Q;      QGplus(QGplus<0)=0;    % QG_CL
QGminus = -(Q - QGplus);                % QG_ML

GraphUp = G + alpha * QGminus;  degsUp = sum(GraphUp);
DUp = sparse(1:n,1:n,degsUp);     L = DUp - GraphUp;

GraphDown = QGplus;             degsDown = sum(GraphDown);
DDown = sparse(1:n,1:n,degsDown);   S = DDown - GraphDown;

%% Solve generalized eigenproblem using the fast Laplacian solver
[ EIGVECTS_raw ] = InversePowerMethod(L,S,nrClust);

%% Compute projection step
EIGVECTS = ProjectionStep(EIGVECTS_raw, degsG, S);   % input('fixEIGS');


end





function EIGVECTS = ProjectionStep(EIGVECTS, degsG, B)

n = length(EIGVECTS);

for i = 1:size(EIGVECTS,2)
    c = - dot(degsG,EIGVECTS(:,i)) / dot(degsG,ones(n,1) );
    EIGVECTS(:,i) = EIGVECTS(:,i) + c * ones(n,1);
    EIGVECTS(:,i) = EIGVECTS(:,i) / sqrt( EIGVECTS(:,i)' * B * EIGVECTS(:,i) );
end


for i=1:n
    EIGVECTS(i,:) = EIGVECTS(i,:) / norm(EIGVECTS(i,:),2);
end

end



function [ EIGS ] = InversePowerMethod(L,S, k)


%  [blockVectorX,lambda,failureFlag,lambdaHistory,residualNormsHistory]=...
%   lobpcg(blockVectorX,'operatorA','operatorB','operatorT',blockVectorY,...
%   residualTolerance,maxIterations,verbosityLevel);
%
%   computes smallest eigenvalues lambda and corresponding eigenvectors
%   blockVectorX of the generalized eigenproblem Ax=lambda Bx, where
%   Hermitian operators operatorA and operatorB are given as functions, as
%   well as a preconditioner, operatorT. The operators operatorB and
%   operatorT must be in addition POSITIVE DEFINITE.

residualTolerance = 1e-3;
maxIterations = 50;
verbosityLevel = 0;

pfun = cmg_sdd(L);
n = length(L);
Sp = S + 1e-08 * L;

[EIGS,lambda,failureFlag]=lobpcg(randn(n,k),L,Sp,@(x)col_pfun(x,pfun),residualTolerance,maxIterations,verbosityLevel);

end


function M = col_pfun( A, pfun )

[n, m] = size(A);
for k=1:m
    M(:,k) = pfun(A(:,k)); 
    M(:,k) = M(:,k)-sum(M(:,k))/n;
end

end





